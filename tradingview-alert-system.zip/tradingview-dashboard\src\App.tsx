import { ConfigProvider, Space, Divider } from 'tdesign-react';
import SignalMonitor from './components/SignalMonitor';
import PositionRiskChart from './components/PositionRiskChart';
import TradeControl from './components/TradeControl';

export default function App() {
  return (
    <ConfigProvider globalConfig={{}}>
      <div style={{ padding: '24px', background: 'linear-gradient(135deg, #0F1621 0%, #1A2A3A 100%)' }}>
        <Space size="large" align="start">
          <SignalMonitor />
          <PositionRiskChart />
        </Space>
        
        <Divider />
        
        <TradeControl />
      </div>
    </ConfigProvider>
  );
}
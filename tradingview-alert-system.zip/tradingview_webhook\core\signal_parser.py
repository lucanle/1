from pydantic import BaseModel  # pyright: ignore[reportMissingImports]
from typing import Optional, Literal
import json

class TradingSignal(BaseModel):
    """标准化交易信号模型"""
    symbol: str
    direction: Literal['BUY', 'SELL']
    entry_price: float
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    alert_name: str
    timeframe: str

def parse_tradingview_alert(payload: str) -> TradingSignal:
    """解析TradingView警报JSON"""
    try:
        data = json.loads(payload)
        return TradingSignal(
            symbol=data.get('symbol'),
            direction=data.get('direction'),
            entry_price=float(data.get('price')),
            stop_loss=float(data.get('stop_loss')) if data.get('stop_loss') else None,
            take_profit=float(data.get('take_profit')) if data.get('take_profit') else None,
            alert_name=data.get('alert_name'),
            timeframe=data.get('timeframe')
        )
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        raise ValueError(f"Invalid alert format: {str(e)}")
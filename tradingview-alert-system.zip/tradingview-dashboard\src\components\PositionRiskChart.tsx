import { Card, Space, Typography } from 'tdesign-react';
import { PieChart, Pie, Cell } from 'recharts';



export default function PositionRiskChart() {
  // 模拟仓位数据
  const positionData = [
    { name: 'BTC', value: 45, color: '#1E90FF' },
    { name: 'ETH', value: 30, color: '#00BFFF' },
    { name: 'SOL', value: 15, color: '#87CEFA' },
    { name: '其他', value: 10, color: '#B0E0E6' }
  ];

  return (
    <Card title="仓位分布" bordered>
      <Space direction="vertical" size="large">
        <PieChart
          width={400}
          height={300}
          data={positionData}
          margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
        >
          <Pie
            data={positionData}
            cx="50%"
            cy="50%"
            outerRadius={80}
            dataKey="value"
            label={({ name, value }) => {
              const total = positionData.reduce((sum, item) => sum + item.value, 0);
              const percent = (value as number) / total;
              return `${name}: ${(percent * 100).toFixed(0)}%`;
            }}
          >
            {positionData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
        </PieChart>
        <Typography.Text>总风险敞口: 15%</Typography.Text>
      </Space>
    </Card>
  );
}
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse
from tradingview_webhook.core.signal_parser import parse_tradingview_alert
from tradingview_webhook.core.trade_executor import TradeExecutor
from tradingview_webhook.core.risk_management import RiskManager
import hmac
import hashlib
import logging
import yaml
from pathlib import Path

app = FastAPI(title="TradingView Webhook Gateway")

# 加载配置文件
CONFIG = yaml.safe_load(Path("config.yaml").read_text())

# 初始化核心组件
trade_executor = TradeExecutor(CONFIG["exchange"])
risk_manager = RiskManager(CONFIG["risk"])

# 配置日志记录
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def verify_signature(secret: str, payload: bytes, signature: str) -> bool:
    """验证TradingView Webhook签名（强制secret非空）"""
    if not secret:
        raise ValueError("Webhook secret cannot be empty")
    """验证TradingView Webhook签名"""
    digest = hmac.new(
        secret.encode(), 
        msg=payload, 
        digestmod=hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(digest, signature)

@app.post("/webhook/tradingview")
async def handle_webhook(request: Request, tv_secret: str):
    """处理TradingView Webhook请求（强制要求密钥）"""
    if not tv_secret:
        raise HTTPException(status_code=400, detail="Webhook secret required")
    """处理TradingView Webhook请求"""
    try:
        payload = await request.body()
        signature = request.headers.get('tv-webhook-signature', '')
        
        if not verify_signature(tv_secret, payload, signature):
            raise HTTPException(status_code=403, detail="Invalid signature")
            
        signal = parse_tradingview_alert(payload.decode())
        logger.info(f"Valid signal received: {signal.json()}")
        
        # 执行风控检查
        if not risk_manager.pre_trade_check(signal):
            raise HTTPException(status_code=403, detail="Risk check failed")
            
        # 执行交易
        order_result = trade_executor.execute_order(signal)
        logger.info(f"Order executed: {order_result}")
        
        return JSONResponse({
            "status": "success",
            "signal": signal.dict(),
            "order": order_result
        })
        
    except Exception as e:
        logger.error(f"Webhook processing error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
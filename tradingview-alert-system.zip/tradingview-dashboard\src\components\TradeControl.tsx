import { Button, Space, Typography, Alert } from 'tdesign-react';
import { useState } from 'react';

export default function TradeControl() {
  const [isTrading, setIsTrading] = useState(true);

  const handleEmergencyStop = () => {
    setIsTrading(false);
    // TODO: 实现紧急平仓逻辑
  };

  return (
    <div style={{ marginTop: '24px' }}>
      <Space direction="vertical" size="large">
        <Typography.Title level="h4">交易控制</Typography.Title>
        
        <Alert
          theme={isTrading ? 'success' : 'warning'}
          message={`交易系统: ${isTrading ? '运行中' : '已暂停'}`}
        />

        <Space>
          <Button
            theme="danger"
            onClick={handleEmergencyStop}
            disabled={!isTrading}
          >
            紧急平仓
          </Button>
          
          <Button
            onClick={() => setIsTrading(!isTrading)}
          >
            {isTrading ? '暂停交易' : '恢复交易'}
          </Button>
        </Space>
      </Space>
    </div>
  );
}
import ccxt
from typing import Dict, Any
from .signal_parser import TradingSignal

class TradeExecutor:
    """CCXT交易执行器"""
    
    def __init__(self, exchange_config: Dict[str, Any]):
        """
        初始化交易所连接
        :param exchange_config: 交易所配置字典
            {
                "exchange_id": "binance",
                "api_key": "your_api_key",
                "secret": "your_secret",
                "enableRateLimit": True
            }
        """
        self.exchange = getattr(ccxt, exchange_config["exchange_id"])({
            'apiKey': exchange_config.get("api_key"),
            'secret': exchange_config.get("secret"),
            'enableRateLimit': True
        })
    
    def execute_order(self, signal: TradingSignal) -> Dict[str, Any]:
        """执行交易信号"""
        try:
            order_params = {
                'symbol': signal.symbol,
                'side': signal.direction.lower(),
                'type': 'limit',
                'price': str(signal.entry_price),
                'amount': self._calculate_position_size(signal)
            }
            
            if signal.stop_loss:
                order_params['stopLossPrice'] = str(signal.stop_loss)
            if signal.take_profit:
                order_params['takeProfitPrice'] = str(signal.take_profit)
                
            return self.exchange.create_order(**order_params)
            
        except ccxt.BaseError as e:
            raise RuntimeError(f"Order execution failed: {str(e)}")
    
    def _calculate_position_size(self, signal: TradingSignal) -> float:
        """计算头寸规模（简化版）"""
        # TODO: 实现基于账户余额和风险参数的头寸计算
        return 0.01  # 默认1%仓位# 创建虚拟环境


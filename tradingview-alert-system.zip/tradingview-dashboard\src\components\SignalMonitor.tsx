import { Card, Space, Typography, Alert } from 'tdesign-react';
import { useState, useEffect } from 'react';

interface TradingSignal {
  symbol: string;
  direction: 'BUY' | 'SELL';
  entry_price: number;
  timestamp: number;
}

export default function SignalMonitor() {
  const [signals, setSignals] = useState<TradingSignal[]>([]);
  
  // TODO: 实现WebSocket连接
  useEffect(() => {
    // 模拟数据
    const mockSignals: TradingSignal[] = [
      {
        symbol: 'BTC/USDT',
        direction: 'BUY',
        entry_price: 50000,
        timestamp: Date.now()
      }
    ];
    setSignals(mockSignals);
  }, []);

  return (
    <Card title="实时信号流" bordered>
      <Space direction="vertical" size="large">
        {signals.map((signal, index) => (
          <Alert
            key={index}
            theme={signal.direction === 'BUY' ? 'success' : 'error'}
            title={`${signal.symbol} ${signal.direction}`}
            message={
              <Typography.Text>
                入场价: {signal.entry_price} | 时间: {new Date(signal.timestamp).toLocaleString()}
              </Typography.Text>
            }
          />
        ))}
      </Space>
    </Card>
  );
}
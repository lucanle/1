from typing import Dict, Any
from .signal_parser import TradingSignal

class RiskManager:
    """基础风控检查模块"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        :param config: 风控配置
            {
                "max_position_percent": 0.1,  # 单币种最大仓位比例
                "max_loss_percent": 0.02,    # 单笔最大亏损比例
                "blacklist": []              # 交易对黑名单
            }
        """
        self.config = config
    
    def pre_trade_check(self, signal: TradingSignal) -> bool:
        """执行交易前风控检查"""
        checks = [
            self._check_blacklist(signal.symbol),
            self._check_position_size(),
            self._check_stop_loss(signal)
        ]
        return all(checks)
    
    def _check_blacklist(self, symbol: str) -> bool:
        """检查交易对是否在黑名单中"""
        return symbol not in self.config.get("blacklist", [])
    
    def _check_position_size(self) -> bool:
        """检查仓位规模（简化版）"""
        # TODO: 实现实际仓位查询
        return True
    
    def _check_stop_loss(self, signal: TradingSignal) -> bool:
        """检查止损设置是否合理"""
        if not signal.stop_loss:
            return False
            
        risk_percent = abs(
            (signal.entry_price - signal.stop_loss) / signal.entry_price
        )
        return risk_percent <= self.config.get("max_loss_percent", 0.05)